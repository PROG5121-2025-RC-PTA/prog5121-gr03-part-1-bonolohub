/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.quiz;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class HardQuestionTest {
    
    public HardQuestionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getDetails method, of class HardQuestion.
     */
    @Test
    public void testGetDetails() {
        
        HardQuestion instance = new HardQuestion("Which planet is known as the Red Planet?", "Mars");
        String expResult = "[Hard] Question: Which planet is known as the Red Planet?";
        
        String result = instance.getDetails();
        
        assertEquals(expResult, result);
        
        }
     @Test
    public void testCheckAnswer() {
        // Arrange
        HardQuestion instance = new HardQuestion("Which planet is known as the Red Planet?", "Mars");

        // Act & Assert
        assertTrue(instance.checkAnswer("Mars")); // Correct answer
        assertTrue(instance.checkAnswer("mars")); // Case insensitive
        assertFalse(instance.checkAnswer("Venus")); // Wrong answer
    }
}
    
    

