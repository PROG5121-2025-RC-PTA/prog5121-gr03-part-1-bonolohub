/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.quiz;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class QuestionTest {
    
    public QuestionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getText method, of class Question.
     */
    @Test
    public void testGetText() {
        
        Question instance = new Question("What is 2+2?", "4");
        String expResult = "What is 2+2?";
        
        String result = instance.getText();
        
        assertEquals(expResult, result);
        
    }
     @Test
    public void testGetAnswer() {
        // Arrange
        Question instance = new Question("What is 2+2?", "4");
        String expResult = "4";

        // Act
        String result = instance.getAnswer();

        // Assert
        assertEquals(expResult, result);
    }

    @Test
    public void testCheckAnswer() {
        // Arrange
        Question instance = new Question("What is 2+2?", "4");

        // Act & Assert
        assertTrue(instance.checkAnswer("4"));   // Correct answer
        assertTrue(instance.checkAnswer("4"));   // Correct with exact match
        assertTrue(instance.checkAnswer("4"));   // Case insensitive (numbers unaffected)
        assertFalse(instance.checkAnswer("5"));  // Wrong answer
    }

    @Test
    public void testGetDetails() {
        // Arrange
        Question instance = new Question("What is 2+2?", "4");
        String expResult = "Question: What is 2+2?";

        // Act
        String result = instance.getDetails();

        // Assert
        assertEquals(expResult, result);
    }
}
    

    
