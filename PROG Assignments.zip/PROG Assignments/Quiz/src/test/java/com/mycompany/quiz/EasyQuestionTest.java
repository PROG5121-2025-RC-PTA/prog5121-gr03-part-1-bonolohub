/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package com.mycompany.quiz;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author User
 */
public class EasyQuestionTest {
    
    public EasyQuestionTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getDetails method, of class EasyQuestion.
     */
    @Test
    public void testGetDetails() {
       
        EasyQuestion instance = new EasyQuestion("What is 2+2?", "4");
        String expResult = "[Easy] Question: What is  2+2?";
        
        
        String result = instance.getDetails();
        
        assertEquals(expResult, result);
    }
        
   @Test
   public void testCheckAnswer(){
       EasyQuestion instance = new EasyQuestion("What is 2+2?", "4");
       
        assertTrue(instance.checkAnswer("4")); // Correct answer
        assertTrue(instance.checkAnswer("4")); // Case insensitive test
        assertFalse(instance.checkAnswer("5")); // Wrong answer
   }
}
