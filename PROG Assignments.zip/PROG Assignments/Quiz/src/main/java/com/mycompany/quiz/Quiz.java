/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quiz;
import java.util.Scanner;

/**
 *
 * @author User
 */

class Question {
    private String text;
    private String answer;

    public Question(String text, String answer) {
        this.text = text;
        this.answer = answer;
    }

    public String getText() { return text; }
    public String getAnswer() { return answer; }

    public boolean checkAnswer(String response) {
        return response.equalsIgnoreCase(answer);
    }

    public String getDetails() {
        return "Question: " + text;
    }
}

// Subclass: Easy Question
class EasyQuestion extends Question {
    public EasyQuestion(String text, String answer) {
        super(text, answer);
    }

    @Override
    public String getDetails() {
        return "[Easy] " + super.getDetails();
    }
}

// Subclass: Hard Question
class HardQuestion extends Question {
    public HardQuestion(String text, String answer) {
        super(text, answer);
    }

    @Override
    public String getDetails() {
        return "[Hard] " + super.getDetails();
    }
}

// Main Game
public class Quiz {
    static Question[] questions = new Question[5]; // Array of questions
    static int score = 0;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Setup questions
        questions[0] = new EasyQuestion("What is 2 + 2?", "4");
        questions[1] = new EasyQuestion("What color is the sky?", "Blue");
        questions[2] = new HardQuestion("What is the capital of South Africa?", "Pretoria");
        questions[3] = new HardQuestion("Which planet is known as the Red Planet?", "Mars");
        questions[4] = new EasyQuestion("What is 10 / 2?", "5");

        System.out.println("Welcome to the Quiz Game");
        System.out.println("Answer the questions below:\n");

        // Loop through questions
        for (int i = 0; i < questions.length; i++) {
            System.out.println(questions[i].getDetails());
            System.out.print("Your answer: ");
            String response = sc.nextLine();

            if (questions[i].checkAnswer(response)) {
                System.out.println("Correct!");
                score++;
            } else {
                System.out.println("Wrong! Correct answer: " + questions[i].getAnswer());
            }
        }

        // Show final score report
        System.out.println("\n--- Quiz Report ---");
        System.out.println("Total Questions: " + questions.length);
        System.out.println("Correct Answers: " + score);
        System.out.println("Final Score: " + (score * 100 / questions.length) + "%");

        sc.close();
    }
}

