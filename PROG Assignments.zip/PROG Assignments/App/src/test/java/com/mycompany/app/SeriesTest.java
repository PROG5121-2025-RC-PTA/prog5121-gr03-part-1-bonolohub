/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.app;



import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author User
 */
public class SeriesTest {
    
 private Series series;

    @BeforeEach
    public void setUp() {
        series = new Series();
        // Add a sample series for testing
        series.addSeries("001", "Cartoon Fun", 5, 12);
    }

    // TestSearchSeries()
    @Test
    public void testSearchSeries() {
        SeriesModel result = series.searchSeriesById("001");
        assertNotNull(result);
        assertEquals("Cartoon Fun", result.SeriesName);
    }

    // TestSearchSeries_SeriesNotFound()
    @Test
    public void testSearchSeries_SeriesNotFound() {
        SeriesModel result = series.searchSeriesById("999");
        assertNull(result);
    }

    // TestUpdateSeries()
    @Test
    public void testUpdateSeries() {
        boolean updated = series.updateSeriesById("001", "Cartoon Mania", 6, 15);
        assertTrue(updated);

        SeriesModel result = series.searchSeriesById("001");
        assertEquals("Cartoon Mania", result.SeriesName);
        assertEquals(6, result.SeriesAge);
        assertEquals(15, result.SeriesNumberOfEpisodes);
    }

    // TestDeleteSeries()
    @Test
    public void testDeleteSeries() {
        boolean deleted = series.deleteSeriesById("001");
        assertTrue(deleted);

        SeriesModel result = series.searchSeriesById("001");
        assertNull(result);
    }

    // TestDeleteSeries_SeriesNotFound()
    @Test
    public void testDeleteSeries_SeriesNotFound() {
        boolean deleted = series.deleteSeriesById("999");
        assertFalse(deleted);
    }

    // TestSeriesAgeRestriction_AgeValid()
    @Test
    public void testSeriesAgeRestriction_AgeValid() {
        assertTrue(series.isValidAge(5));
        assertTrue(series.isValidAge(2));
        assertTrue(series.isValidAge(18));
    }

    // TestSeriesAgeRestriction_SeriesAgeInValid()
    @Test
    public void testSeriesAgeRestriction_SeriesAgeInValid() {
        assertFalse(series.isValidAge(1));
        assertFalse(series.isValidAge(19));
        assertFalse(series.isValidAge(-5));
    }
}  
