/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.app;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author User
 */
public class AppTest {
    
    @Test
    public void testMainRuns() {
        // This test ensures the main method runs without throwing exceptions
        String[] args = {};
        try {
            App.main(args);
        } catch (Exception e) {
            fail("App.main() threw an exception: " + e.getMessage());
        }
    }
}

