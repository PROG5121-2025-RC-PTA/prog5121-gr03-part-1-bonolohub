/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.app;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author User
 */
public class SeriesModelTest {
    
  @Test
    public void testSeriesModelConstructor() {
        SeriesModel series = new SeriesModel("001", "Cartoon Fun", 5, 12);

        assertEquals("001", series.SeriesId);
        assertEquals("Cartoon Fun", series.SeriesName);
        assertEquals(5, series.SeriesAge);
        assertEquals(12, series.SeriesNumberOfEpisodes);
    }
}  
    

