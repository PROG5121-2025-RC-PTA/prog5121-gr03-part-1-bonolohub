/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.app;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author User
 */
class SeriesModel {
    public String SeriesId;
    public String SeriesName;
    public int SeriesAge;
    public int SeriesNumberOfEpisodes;
    
    public SeriesModel (String id, String name, int age, int episodes){
        
        this.SeriesId = id;
        this.SeriesName = name;
        this.SeriesAge = age;
        this.SeriesNumberOfEpisodes = episodes;
    }
    
}

class Series {
     ArrayList<SeriesModel> seriesList = new ArrayList<>();
     Scanner input = new Scanner(System.in);

    // 1. Capture new series
    public void CaptureSeries() {
        System.out.print("Enter Series ID: ");
        String id = input.nextLine();

        System.out.print("Enter Series Name: ");
        String name = input.nextLine();
        
        int age = 0;

        // Age restriction validation
        while (true) {
            try {
            System.out.print("Enter Age Restriction (2 - 18): ");
            age = Integer.parseInt (input.nextLine());
            if (age >= 2 && age <= 18) break;
            else System.out.println("Invalid age. Please enter between 2 and 18.");
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a number.");
            }
        }
        
        System.out.print("Enter Number of Episodes: ");
        int episodes = Integer.parseInt(input.nextLine());

        seriesList.add(new SeriesModel (id, name, age, episodes));
        System.out.println("Series details successfully saved!");
        
        
    }

    // 2. Search for a series
    public void SearchSeries() {
        System.out.print("Enter Series ID to search: ");
        String id = input.nextLine();

        for (SeriesModel s : seriesList) {
            if (s.SeriesId.equals(id)) {
               DisplaySeries (s);
               return;
            }
        }
        System.out.println("No series data could be found.");
    }

    // 3. Update series
    public void UpdateSeries() {
        System.out.print("Enter Series ID to update: ");
        String id = input.nextLine();

        for (SeriesModel s : seriesList) {
            if (s.SeriesId.equals(id)) {
                System.out.print("Enter new Series Name: ");
                s.SeriesName = input.nextLine();
                
                int age = 0;

                while (true) {
                   try {
                        System.out.print("Enter new Age Restriction (2 - 18): ");
                        age = Integer.parseInt (input.nextLine());
                        if (age >= 2 && age <= 18)break;
                        else System.out.println("Invalid! Age must be between 2 and 18.");
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid input. Please enter a number.");
                    }
                }
                s.SeriesAge = age;
                System.out.print("Enter new Number of Episodes: ");
                s.SeriesNumberOfEpisodes = Integer.parseInt (input.nextLine());

                System.out.println("Series updated successfully!");
                return;
            }
        }
        System.out.println("No series found with ID: " + id);
    }

    // 4. Delete series
    public void DeleteSeries() {
        System.out.print("Enter Series ID to delete: ");
        String id = input.nextLine();

        for (SeriesModel s : seriesList) {
            if (s.SeriesId.equals(id)) {
                System.out.print("Are you sure you want to delete this series? (Yes/No): ");
                String confirm = input.nextLine();
                if (confirm.equalsIgnoreCase("Yes")) {
                    seriesList.remove(s);
                    System.out.println("Series deleted successfully.");
                }
                return;
            }
        }
        System.out.println("No series found with ID: " + id);
    }

    // 5. Display report
    public void SeriesReport() {
        if (seriesList.isEmpty()) {
            System.out.println("No series available.");
            return;
        } 
        System.out.println("--------------------------------------------------");
        int count = 1;
        for (SeriesModel s : seriesList){
            System.out.println("Series " + count++);
            DisplaySeries (s);
            System.out.println("-----------------------------------------------");    
            }
        }
        
        // 6. Exit application
    public void ExitSeriesApplication() {
        System.out.println("Exiting application...");
        System.exit(0);
    }
    
    private void DisplaySeries (SeriesModel s){
        System.out.println("SERIES ID: " + s.SeriesId);
        System.out.println("SERIES NAME: " + s.SeriesName);
        System.out.println("SERIES AGE REGIDTRATION: " + s.SeriesAge);
        System.out.println("NUMBER OF EPISODES: " + s.SeriesNumberOfEpisodes);
        
    }
    
     public void addSeries(String id, String name, int age, int episodes) {
        seriesList.add(new SeriesModel(id, name, age, episodes));
}
     
   public SeriesModel searchSeriesById(String id) {
        for (SeriesModel s : seriesList) {
            if (s.SeriesId.equals(id)) {
                return s;
            }
        }
        return null;
    }

    public boolean updateSeriesById(String id, String newName, int newAge, int newEpisodes) {
        SeriesModel s = searchSeriesById(id);
        if (s != null) {
            s.SeriesName = newName;
            s.SeriesAge = newAge;
            s.SeriesNumberOfEpisodes = newEpisodes;
            return true;
        }
        return false;
    }

    public boolean deleteSeriesById(String id) {
        SeriesModel s = searchSeriesById(id);
        if (s != null) {
            seriesList.remove(s);
            return true;
        }
        return false;
    }

    public boolean isValidAge(int age) {
        return age >= 2 && age <= 18;
    }
}
  
        
public class App {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Series seriesApp = new Series();

        while (true) {
            System.out.println("\nPlease select one of the following menue items:");
            System.out.println("(1) Capture a new series");
            System.out.println("(2) Search for a series");
            System.out.println("(3) Update a series age restriction");
            System.out.println("(4) Delete a series");
            System.out.println("(5) Print series Report - 2025");
            System.out.println("(6) Exit Application");
            System.out.print("Enter your choice: ");
            
            
            String choice = input.nextLine();
            
           
            switch (choice) {
                case "1":
                    seriesApp.CaptureSeries();
                    break;
                case "2":
                    seriesApp.SearchSeries();
                    break;
                case "3":
                    seriesApp.UpdateSeries();
                    break;
                case "4":
                    seriesApp.DeleteSeries();
                    break;
                case "5":
                    seriesApp.SeriesReport();
                    break;
                case "6":
                    seriesApp.ExitSeriesApplication();
                    break;
                default:
                    System.out.println("Invalid choice! Try again.");
            }
        }
    }
}

